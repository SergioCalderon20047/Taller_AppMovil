import React from 'react'
import {Modal, Text, Button, StyleSheet, View, TextInput, ScrollView, Pressable} from 'react-native';
import DatePicker from 'react-native-date-picker';

const Formulario = ({modalVisible}) => {
  const [paciente, setPaciente] = useState('')
  const [propietario, setPropietario] = useState('')
  const [email, setEmail] = useState('')
  const [telefono, setTelefono] = useState('')
  const [fecha, setFecha] = useState(new Date())
  const [sintomas, setSintomas] = useState('')


  const Formulario = ({modalVisible, setModalVisible}) => {
    const [pacinete, setPaciente] = useState('')
  }

  return (
    <Modal animationType='slice' visible={modalVisible}>
        <View style={styles.contenido}>
          <ScrollView></ScrollView>
            <Text style={styles.titulo}> Nueva{''}
                <Text style={styles.titulobold}>Cita</Text>
            </Text>

            <Pressable
              style={styles.btnCancelar}
              onLongPress={() => setModalVisible(!modalVisible)}>
              <Text style={styles.btnCancelarTexto}>X Cancelar</Text>
            </Pressable>


            <Pressable
              style={styles.btnnuevacita}
              onPress={()=>setModalVisible(true)}>
              <Text style={styles.btntextnuevascitas}>Nueva Cita</Text>
            </Pressable>
            <Formulario
              modalVisible={modalVisible}
              setModalVisible
            />
        </View>

        <View style={styles.campo}>
          <Text style={styles.label}>Nombre Paciente</Text>
          <TextInput
          style={styles.input}
          placeholder='Nombre del Paciente'
          placeholderTextColor={'#666'}
          onChangeText={setPaciente}/>
        </View>
        <View style={styles.campo}>
          <Text style={styles.label}>Nombre del Propietario</Text>
          <TextInput
          style={styles.input}
          placeholder='Nombre del Propietario'
          placeholderTextColor={'#666'}
          onChangeText={setPropietario}/>
        </View>
        <View style={styles.campo}>
          <Text style={styles.label}>Email Propietario</Text>
          <TextInput
          style={styles.input}
          placeholder='email'
          placeholderTextColor={'#666'}
          keyboardType='email-address'
          onChangeText={setEmail}/>
        </View>
        <View style={styles.campo}>
          <Text style={styles.label}>Telefono Propietario</Text>
          <TextInput
          style={styles.input}
          placeholder='Telefono del Propietario'
          placeholderTextColor={'#666'}
          keyboardType='number-pad'
          onChangeText={setTelefono}
          maxLength={10}
          />
        </View>
        <View style={styles.campo}>
          <Text style={styles.label}>Fecha Alta</Text>
          <DataPicker
            date={fecha}
            locale='es'//para que este en español
            mode='date'
            onValueChange={(date)=>setFecha(date)}//para seleccionar la fecha 
          />
        </View>
        <View style={styles.campo}>
          <Text style={styles.label}>Sintomas</Text>
          <TextInput
          style={styles.input}
          placeholder='Sintomas Paciente'
          placeholderTextColor={'#666'}
          keyboardType='number-pad'
          onChangeText={setSintomas}
          multiline={true}
          numberOfLines={4}
          />
          <Pressable style={styles.btnNuevaCita}>
              <Text style={styles.btnNuevaCitaTexto}>Agregar Paciente</Text>
          </Pressable>
        </View>
    </Modal>
  );
}

const styles=StyleSheet.create({
      contenido: {
        backgroundColor: '#6D28D9',
        flex: 1,
      },
      titulo: {
        fontSize: 30,
        fontWeight: '600',
        textAlign: 'center',
        marginTop: 30,
        color: '#fff',
      },
      titulobold: {
        fontWeight: '900',
      },
      btnCancelar: {
        marginVertical: 30,
        backgroundColor: '#5827A4',
        marginHorizontal: 30,
        padding: 15,
        borderRadius: 10,
        borderWidth: 1,
        borderColor: '#FFF'
      },
      btnCancelarTexto: {
        color: '#FFF',
        textAlign: 'center',
        fontWeight: '900',
        fontSize: 16,
        textTransform: 'uppercase',
      },
      campo: {
        marginTop: 10,
        marginHorizontal: 30,
      },
      label: {
        color: '#FFF',
        marginBottom: 10,
        marginTop: 15,
        fontSize: 20,
        fontWeight: '600',
      },
      input: {
        backgroundColor: '#FFF',
        padding: 15,
        borderRadius: 10,
      },
      sintomasInput: {
        height: 100,
      },
      fechacontenedor: {
        backgroundColor: '#FFF',
        borderRadius: 10,
      },
      btnNuevaCita:{
        marginVertical: 50,
        backgroundColor: '#F59E0B',
        paddingVertical: 10,
        paddingHorizontal: 30,
        borderRadius: 10,
      },
      btnNuevaCitaTexto: {
        textAlign: 'center',
        color: '#5827A4',
        textTransform: 'uppercase',
        fontWeight: '900',
        fontSize: 16,
      },
})

export default Formulario